const config={
    emailUser:process.env.EMAILUSER,
    emailPassword:process.env.EMAILPASSWORD,
    method:'plain'
}

module.exports={
    config
}